// Generated from /home/jekabsvanags/grammar/imp/imprw.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link imprwParser}.
 */
public interface imprwListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link imprwParser#progr}.
	 * @param ctx the parse tree
	 */
	void enterProgr(imprwParser.ProgrContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#progr}.
	 * @param ctx the parse tree
	 */
	void exitProgr(imprwParser.ProgrContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#series}.
	 * @param ctx the parse tree
	 */
	void enterSeries(imprwParser.SeriesContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#series}.
	 * @param ctx the parse tree
	 */
	void exitSeries(imprwParser.SeriesContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(imprwParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(imprwParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#inputStmt}.
	 * @param ctx the parse tree
	 */
	void enterInputStmt(imprwParser.InputStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#inputStmt}.
	 * @param ctx the parse tree
	 */
	void exitInputStmt(imprwParser.InputStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#outputStmt}.
	 * @param ctx the parse tree
	 */
	void enterOutputStmt(imprwParser.OutputStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#outputStmt}.
	 * @param ctx the parse tree
	 */
	void exitOutputStmt(imprwParser.OutputStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#assignStmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignStmt(imprwParser.AssignStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#assignStmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignStmt(imprwParser.AssignStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#condStmt}.
	 * @param ctx the parse tree
	 */
	void enterCondStmt(imprwParser.CondStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#condStmt}.
	 * @param ctx the parse tree
	 */
	void exitCondStmt(imprwParser.CondStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#loop}.
	 * @param ctx the parse tree
	 */
	void enterLoop(imprwParser.LoopContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#loop}.
	 * @param ctx the parse tree
	 */
	void exitLoop(imprwParser.LoopContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#compar}.
	 * @param ctx the parse tree
	 */
	void enterCompar(imprwParser.ComparContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#compar}.
	 * @param ctx the parse tree
	 */
	void exitCompar(imprwParser.ComparContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#comparterm}.
	 * @param ctx the parse tree
	 */
	void enterComparterm(imprwParser.CompartermContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#comparterm}.
	 * @param ctx the parse tree
	 */
	void exitComparterm(imprwParser.CompartermContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#comparelem}.
	 * @param ctx the parse tree
	 */
	void enterComparelem(imprwParser.ComparelemContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#comparelem}.
	 * @param ctx the parse tree
	 */
	void exitComparelem(imprwParser.ComparelemContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#varlist}.
	 * @param ctx the parse tree
	 */
	void enterVarlist(imprwParser.VarlistContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#varlist}.
	 * @param ctx the parse tree
	 */
	void exitVarlist(imprwParser.VarlistContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(imprwParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(imprwParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#term}.
	 * @param ctx the parse tree
	 */
	void enterTerm(imprwParser.TermContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#term}.
	 * @param ctx the parse tree
	 */
	void exitTerm(imprwParser.TermContext ctx);
	/**
	 * Enter a parse tree produced by {@link imprwParser#elem}.
	 * @param ctx the parse tree
	 */
	void enterElem(imprwParser.ElemContext ctx);
	/**
	 * Exit a parse tree produced by {@link imprwParser#elem}.
	 * @param ctx the parse tree
	 */
	void exitElem(imprwParser.ElemContext ctx);
}