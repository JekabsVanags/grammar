# Generated from imprw.g4 by ANTLR 4.7.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\33")
        buf.write("\u009f\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\3\2\3\2\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\7\3)\n\3\f\3\16\3,\13\3\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\5\4\65\n\4\3\4\3\4\3\4\7\4:\n\4\f\4\16\4=\13\4\3\5")
        buf.write("\3\5\3\5\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3")
        buf.write("\b\3\b\5\bO\n\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3")
        buf.write("\n\3\n\3\n\3\n\3\n\7\n_\n\n\f\n\16\nb\13\n\3\13\3\13\3")
        buf.write("\13\3\13\3\13\3\13\7\13j\n\13\f\13\16\13m\13\13\3\f\3")
        buf.write("\f\3\f\3\f\3\f\3\f\3\f\5\fv\n\f\3\r\3\r\3\r\7\r{\n\r\f")
        buf.write("\r\16\r~\13\r\3\16\3\16\3\16\3\16\3\16\3\16\7\16\u0086")
        buf.write("\n\16\f\16\16\16\u0089\13\16\3\17\3\17\3\17\3\17\3\17")
        buf.write("\3\17\7\17\u0091\n\17\f\17\16\17\u0094\13\17\3\20\3\20")
        buf.write("\3\20\3\20\3\20\3\20\3\20\5\20\u009d\n\20\3\20\2\b\4\6")
        buf.write("\22\24\32\34\21\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36")
        buf.write("\2\2\2\u00a1\2 \3\2\2\2\4\"\3\2\2\2\6\64\3\2\2\2\b>\3")
        buf.write("\2\2\2\nA\3\2\2\2\fD\3\2\2\2\16H\3\2\2\2\20R\3\2\2\2\22")
        buf.write("X\3\2\2\2\24c\3\2\2\2\26u\3\2\2\2\30w\3\2\2\2\32\177\3")
        buf.write("\2\2\2\34\u008a\3\2\2\2\36\u009c\3\2\2\2 !\5\4\3\2!\3")
        buf.write("\3\2\2\2\"#\b\3\1\2#$\5\6\4\2$*\3\2\2\2%&\f\3\2\2&\'\7")
        buf.write("\3\2\2\')\5\6\4\2(%\3\2\2\2),\3\2\2\2*(\3\2\2\2*+\3\2")
        buf.write("\2\2+\5\3\2\2\2,*\3\2\2\2-.\b\4\1\2.\65\5\b\5\2/\65\5")
        buf.write("\n\6\2\60\65\5\f\7\2\61\65\5\16\b\2\62\65\5\20\t\2\63")
        buf.write("\65\7\4\2\2\64-\3\2\2\2\64/\3\2\2\2\64\60\3\2\2\2\64\61")
        buf.write("\3\2\2\2\64\62\3\2\2\2\64\63\3\2\2\2\65;\3\2\2\2\66\67")
        buf.write("\f\4\2\2\678\7\3\2\28:\5\6\4\59\66\3\2\2\2:=\3\2\2\2;")
        buf.write("9\3\2\2\2;<\3\2\2\2<\7\3\2\2\2=;\3\2\2\2>?\7\5\2\2?@\5")
        buf.write("\30\r\2@\t\3\2\2\2AB\7\6\2\2BC\5\30\r\2C\13\3\2\2\2DE")
        buf.write("\7\26\2\2EF\7\7\2\2FG\5\32\16\2G\r\3\2\2\2HI\7\b\2\2I")
        buf.write("J\5\22\n\2JK\7\t\2\2KN\5\4\3\2LM\7\n\2\2MO\5\4\3\2NL\3")
        buf.write("\2\2\2NO\3\2\2\2OP\3\2\2\2PQ\7\13\2\2Q\17\3\2\2\2RS\7")
        buf.write("\f\2\2ST\5\22\n\2TU\7\r\2\2UV\5\4\3\2VW\7\16\2\2W\21\3")
        buf.write("\2\2\2XY\b\n\1\2YZ\5\24\13\2Z`\3\2\2\2[\\\f\3\2\2\\]\7")
        buf.write("\17\2\2]_\5\24\13\2^[\3\2\2\2_b\3\2\2\2`^\3\2\2\2`a\3")
        buf.write("\2\2\2a\23\3\2\2\2b`\3\2\2\2cd\b\13\1\2de\5\26\f\2ek\3")
        buf.write("\2\2\2fg\f\3\2\2gh\7\20\2\2hj\5\26\f\2if\3\2\2\2jm\3\2")
        buf.write("\2\2ki\3\2\2\2kl\3\2\2\2l\25\3\2\2\2mk\3\2\2\2no\5\32")
        buf.write("\16\2op\7\27\2\2pq\5\32\16\2qv\3\2\2\2rv\5\32\16\2st\7")
        buf.write("\21\2\2tv\5\22\n\2un\3\2\2\2ur\3\2\2\2us\3\2\2\2v\27\3")
        buf.write("\2\2\2w|\7\26\2\2xy\7\22\2\2y{\7\26\2\2zx\3\2\2\2{~\3")
        buf.write("\2\2\2|z\3\2\2\2|}\3\2\2\2}\31\3\2\2\2~|\3\2\2\2\177\u0080")
        buf.write("\b\16\1\2\u0080\u0081\5\34\17\2\u0081\u0087\3\2\2\2\u0082")
        buf.write("\u0083\f\3\2\2\u0083\u0084\7\30\2\2\u0084\u0086\5\34\17")
        buf.write("\2\u0085\u0082\3\2\2\2\u0086\u0089\3\2\2\2\u0087\u0085")
        buf.write("\3\2\2\2\u0087\u0088\3\2\2\2\u0088\33\3\2\2\2\u0089\u0087")
        buf.write("\3\2\2\2\u008a\u008b\b\17\1\2\u008b\u008c\5\36\20\2\u008c")
        buf.write("\u0092\3\2\2\2\u008d\u008e\f\3\2\2\u008e\u008f\7\31\2")
        buf.write("\2\u008f\u0091\5\36\20\2\u0090\u008d\3\2\2\2\u0091\u0094")
        buf.write("\3\2\2\2\u0092\u0090\3\2\2\2\u0092\u0093\3\2\2\2\u0093")
        buf.write("\35\3\2\2\2\u0094\u0092\3\2\2\2\u0095\u009d\7\26\2\2\u0096")
        buf.write("\u009d\7\25\2\2\u0097\u009d\7\32\2\2\u0098\u0099\7\23")
        buf.write("\2\2\u0099\u009a\5\32\16\2\u009a\u009b\7\24\2\2\u009b")
        buf.write("\u009d\3\2\2\2\u009c\u0095\3\2\2\2\u009c\u0096\3\2\2\2")
        buf.write("\u009c\u0097\3\2\2\2\u009c\u0098\3\2\2\2\u009d\37\3\2")
        buf.write("\2\2\r*\64;N`ku|\u0087\u0092\u009c")
        return buf.getvalue()


class imprwParser ( Parser ):

    grammarFileName = "imprw.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'skip'", "'read'", "'write'", 
                     "':='", "'if'", "'then'", "'else'", "'fi'", "'while'", 
                     "'do'", "'od'", "'or'", "'and'", "'not'", "','", "'('", 
                     "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "NUMBER", "VARNAME", 
                      "RELATION", "WEAKOP", "STRONGOP", "TRUTHVAL", "WS" ]

    RULE_progr = 0
    RULE_series = 1
    RULE_stmt = 2
    RULE_inputStmt = 3
    RULE_outputStmt = 4
    RULE_assignStmt = 5
    RULE_condStmt = 6
    RULE_loop = 7
    RULE_compar = 8
    RULE_comparterm = 9
    RULE_comparelem = 10
    RULE_varlist = 11
    RULE_expr = 12
    RULE_term = 13
    RULE_elem = 14

    ruleNames =  [ "progr", "series", "stmt", "inputStmt", "outputStmt", 
                   "assignStmt", "condStmt", "loop", "compar", "comparterm", 
                   "comparelem", "varlist", "expr", "term", "elem" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    NUMBER=19
    VARNAME=20
    RELATION=21
    WEAKOP=22
    STRONGOP=23
    TRUTHVAL=24
    WS=25

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgrContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def series(self):
            return self.getTypedRuleContext(imprwParser.SeriesContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_progr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgr" ):
                listener.enterProgr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgr" ):
                listener.exitProgr(self)




    def progr(self):

        localctx = imprwParser.ProgrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_progr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 30
            self.series(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SeriesContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self):
            return self.getTypedRuleContext(imprwParser.StmtContext,0)


        def series(self):
            return self.getTypedRuleContext(imprwParser.SeriesContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_series

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSeries" ):
                listener.enterSeries(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSeries" ):
                listener.exitSeries(self)



    def series(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.SeriesContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_series, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33
            self.stmt(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 40
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,0,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.SeriesContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_series)
                    self.state = 35
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 36
                    self.match(imprwParser.T__0)
                    self.state = 37
                    self.stmt(0) 
                self.state = 42
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class StmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def inputStmt(self):
            return self.getTypedRuleContext(imprwParser.InputStmtContext,0)


        def outputStmt(self):
            return self.getTypedRuleContext(imprwParser.OutputStmtContext,0)


        def assignStmt(self):
            return self.getTypedRuleContext(imprwParser.AssignStmtContext,0)


        def condStmt(self):
            return self.getTypedRuleContext(imprwParser.CondStmtContext,0)


        def loop(self):
            return self.getTypedRuleContext(imprwParser.LoopContext,0)


        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(imprwParser.StmtContext)
            else:
                return self.getTypedRuleContext(imprwParser.StmtContext,i)


        def getRuleIndex(self):
            return imprwParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)



    def stmt(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.StmtContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_stmt, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 50
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [imprwParser.T__2]:
                self.state = 44
                self.inputStmt()
                pass
            elif token in [imprwParser.T__3]:
                self.state = 45
                self.outputStmt()
                pass
            elif token in [imprwParser.VARNAME]:
                self.state = 46
                self.assignStmt()
                pass
            elif token in [imprwParser.T__5]:
                self.state = 47
                self.condStmt()
                pass
            elif token in [imprwParser.T__9]:
                self.state = 48
                self.loop()
                pass
            elif token in [imprwParser.T__1]:
                self.state = 49
                self.match(imprwParser.T__1)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 57
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.StmtContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_stmt)
                    self.state = 52
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 53
                    self.match(imprwParser.T__0)
                    self.state = 54
                    self.stmt(3) 
                self.state = 59
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class InputStmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varlist(self):
            return self.getTypedRuleContext(imprwParser.VarlistContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_inputStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInputStmt" ):
                listener.enterInputStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInputStmt" ):
                listener.exitInputStmt(self)




    def inputStmt(self):

        localctx = imprwParser.InputStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_inputStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self.match(imprwParser.T__2)
            self.state = 61
            self.varlist()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class OutputStmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varlist(self):
            return self.getTypedRuleContext(imprwParser.VarlistContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_outputStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutputStmt" ):
                listener.enterOutputStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutputStmt" ):
                listener.exitOutputStmt(self)




    def outputStmt(self):

        localctx = imprwParser.OutputStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_outputStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 63
            self.match(imprwParser.T__3)
            self.state = 64
            self.varlist()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class AssignStmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARNAME(self):
            return self.getToken(imprwParser.VARNAME, 0)

        def expr(self):
            return self.getTypedRuleContext(imprwParser.ExprContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_assignStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignStmt" ):
                listener.enterAssignStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignStmt" ):
                listener.exitAssignStmt(self)




    def assignStmt(self):

        localctx = imprwParser.AssignStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_assignStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 66
            self.match(imprwParser.VARNAME)
            self.state = 67
            self.match(imprwParser.T__4)
            self.state = 68
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CondStmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def compar(self):
            return self.getTypedRuleContext(imprwParser.ComparContext,0)


        def series(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(imprwParser.SeriesContext)
            else:
                return self.getTypedRuleContext(imprwParser.SeriesContext,i)


        def getRuleIndex(self):
            return imprwParser.RULE_condStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondStmt" ):
                listener.enterCondStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondStmt" ):
                listener.exitCondStmt(self)




    def condStmt(self):

        localctx = imprwParser.CondStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_condStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            self.match(imprwParser.T__5)
            self.state = 71
            self.compar(0)
            self.state = 72
            self.match(imprwParser.T__6)
            self.state = 73
            self.series(0)
            self.state = 76
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==imprwParser.T__7:
                self.state = 74
                self.match(imprwParser.T__7)
                self.state = 75
                self.series(0)


            self.state = 78
            self.match(imprwParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class LoopContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def compar(self):
            return self.getTypedRuleContext(imprwParser.ComparContext,0)


        def series(self):
            return self.getTypedRuleContext(imprwParser.SeriesContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_loop

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLoop" ):
                listener.enterLoop(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLoop" ):
                listener.exitLoop(self)




    def loop(self):

        localctx = imprwParser.LoopContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_loop)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.match(imprwParser.T__9)
            self.state = 81
            self.compar(0)
            self.state = 82
            self.match(imprwParser.T__10)
            self.state = 83
            self.series(0)
            self.state = 84
            self.match(imprwParser.T__11)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ComparContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparterm(self):
            return self.getTypedRuleContext(imprwParser.CompartermContext,0)


        def compar(self):
            return self.getTypedRuleContext(imprwParser.ComparContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_compar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompar" ):
                listener.enterCompar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompar" ):
                listener.exitCompar(self)



    def compar(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.ComparContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_compar, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self.comparterm(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 94
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.ComparContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_compar)
                    self.state = 89
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 90
                    self.match(imprwParser.T__12)
                    self.state = 91
                    self.comparterm(0) 
                self.state = 96
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class CompartermContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparelem(self):
            return self.getTypedRuleContext(imprwParser.ComparelemContext,0)


        def comparterm(self):
            return self.getTypedRuleContext(imprwParser.CompartermContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_comparterm

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparterm" ):
                listener.enterComparterm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparterm" ):
                listener.exitComparterm(self)



    def comparterm(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.CompartermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 18
        self.enterRecursionRule(localctx, 18, self.RULE_comparterm, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 98
            self.comparelem()
            self._ctx.stop = self._input.LT(-1)
            self.state = 105
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.CompartermContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_comparterm)
                    self.state = 100
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 101
                    self.match(imprwParser.T__13)
                    self.state = 102
                    self.comparelem() 
                self.state = 107
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class ComparelemContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(imprwParser.ExprContext)
            else:
                return self.getTypedRuleContext(imprwParser.ExprContext,i)


        def RELATION(self):
            return self.getToken(imprwParser.RELATION, 0)

        def compar(self):
            return self.getTypedRuleContext(imprwParser.ComparContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_comparelem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparelem" ):
                listener.enterComparelem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparelem" ):
                listener.exitComparelem(self)




    def comparelem(self):

        localctx = imprwParser.ComparelemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_comparelem)
        try:
            self.state = 115
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 108
                self.expr(0)
                self.state = 109
                self.match(imprwParser.RELATION)
                self.state = 110
                self.expr(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 112
                self.expr(0)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 113
                self.match(imprwParser.T__14)
                self.state = 114
                self.compar(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarlistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARNAME(self, i:int=None):
            if i is None:
                return self.getTokens(imprwParser.VARNAME)
            else:
                return self.getToken(imprwParser.VARNAME, i)

        def getRuleIndex(self):
            return imprwParser.RULE_varlist

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarlist" ):
                listener.enterVarlist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarlist" ):
                listener.exitVarlist(self)




    def varlist(self):

        localctx = imprwParser.VarlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_varlist)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(imprwParser.VARNAME)
            self.state = 122
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 118
                    self.match(imprwParser.T__15)
                    self.state = 119
                    self.match(imprwParser.VARNAME) 
                self.state = 124
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self):
            return self.getTypedRuleContext(imprwParser.TermContext,0)


        def expr(self):
            return self.getTypedRuleContext(imprwParser.ExprContext,0)


        def WEAKOP(self):
            return self.getToken(imprwParser.WEAKOP, 0)

        def getRuleIndex(self):
            return imprwParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 24
        self.enterRecursionRule(localctx, 24, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.term(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 133
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.ExprContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                    self.state = 128
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 129
                    self.match(imprwParser.WEAKOP)
                    self.state = 130
                    self.term(0) 
                self.state = 135
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class TermContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def elem(self):
            return self.getTypedRuleContext(imprwParser.ElemContext,0)


        def term(self):
            return self.getTypedRuleContext(imprwParser.TermContext,0)


        def STRONGOP(self):
            return self.getToken(imprwParser.STRONGOP, 0)

        def getRuleIndex(self):
            return imprwParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)



    def term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = imprwParser.TermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 26
        self.enterRecursionRule(localctx, 26, self.RULE_term, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.elem()
            self._ctx.stop = self._input.LT(-1)
            self.state = 144
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = imprwParser.TermContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                    self.state = 139
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 140
                    self.match(imprwParser.STRONGOP)
                    self.state = 141
                    self.elem() 
                self.state = 146
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class ElemContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARNAME(self):
            return self.getToken(imprwParser.VARNAME, 0)

        def NUMBER(self):
            return self.getToken(imprwParser.NUMBER, 0)

        def TRUTHVAL(self):
            return self.getToken(imprwParser.TRUTHVAL, 0)

        def expr(self):
            return self.getTypedRuleContext(imprwParser.ExprContext,0)


        def getRuleIndex(self):
            return imprwParser.RULE_elem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElem" ):
                listener.enterElem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElem" ):
                listener.exitElem(self)




    def elem(self):

        localctx = imprwParser.ElemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_elem)
        try:
            self.state = 154
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [imprwParser.VARNAME]:
                self.enterOuterAlt(localctx, 1)
                self.state = 147
                self.match(imprwParser.VARNAME)
                pass
            elif token in [imprwParser.NUMBER]:
                self.enterOuterAlt(localctx, 2)
                self.state = 148
                self.match(imprwParser.NUMBER)
                pass
            elif token in [imprwParser.TRUTHVAL]:
                self.enterOuterAlt(localctx, 3)
                self.state = 149
                self.match(imprwParser.TRUTHVAL)
                pass
            elif token in [imprwParser.T__16]:
                self.enterOuterAlt(localctx, 4)
                self.state = 150
                self.match(imprwParser.T__16)
                self.state = 151
                self.expr(0)
                self.state = 152
                self.match(imprwParser.T__17)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.series_sempred
        self._predicates[2] = self.stmt_sempred
        self._predicates[8] = self.compar_sempred
        self._predicates[9] = self.comparterm_sempred
        self._predicates[12] = self.expr_sempred
        self._predicates[13] = self.term_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def series_sempred(self, localctx:SeriesContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 1)
         

    def stmt_sempred(self, localctx:StmtContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def compar_sempred(self, localctx:ComparContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 1)
         

    def comparterm_sempred(self, localctx:CompartermContext, predIndex:int):
            if predIndex == 3:
                return self.precpred(self._ctx, 1)
         

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 1)
         

    def term_sempred(self, localctx:TermContext, predIndex:int):
            if predIndex == 5:
                return self.precpred(self._ctx, 1)
         




